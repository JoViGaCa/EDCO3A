/**
* @file ex05.c
* @author João Carvalho
* @date 18 06 2021
* @brief Defina um tipo abstrato de dados que ir´a representar bandas de m´usica.
Essa estrutura deve ter o nome da banda, que tipo de m´usica ela toca, o n´umero de integrantes, e em que
posi¸c˜ao do ranking essa banda est´a dentre as suas 5 bandas favoritas.
a) Crie uma fun¸c˜ao para preencher as 5 estruturas de bandas criadas no exemplo passado;
b) Ap´os criar e preencher, exiba todas as informa¸c˜oes das bandas/estruturas. N˜ao se esque¸ca de usar o
operador → para preencher os membros das structs;
c) Crie uma fun¸c˜ao que pe¸ca ao usu´ario um n´umero de 1 at´e 5. Em seguida, seu programa deve exibir
informa¸c˜oes da banda cuja posi¸c˜ao no seu ranking ´e a que foi solicitada pelo usu´ario.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// estrutura com nome, tipo, numero de integrante e posição do rank
typedef struct{
  char nome [16];
  char tipo [11];
  int num_int;
  int pos_rank;
} Banda;

int preenchVet(Banda* banda, int n){
  // repetição controlada para receber os valores
  for(int i = 0; i < n; i++){
    printf("Por favor digite o nome da banda %i:\n", i+1);
    fgets(banda[i].nome,16,stdin);
    banda[i].nome[strcspn(banda[i].nome, "\n")] = '\0';
    setbuf(stdin, NULL);
    printf("Por favor digite o tipo da banda %i:\n", i+1);
    fgets(banda[i].tipo,11,stdin);
    banda[i].tipo[strcspn(banda[i].tipo, "\n")] = '\0';
    setbuf(stdin, NULL);
    printf("Por favor digite a quantidade de integrantes:\n");
    scanf("%i", &banda[i].num_int);
    printf("Por favor digite a posição no ranking:\n");
    scanf("%i", &banda[i].pos_rank);
    setbuf(stdin,NULL);
  }
  return 0;
}

int exibeVet(Banda *banda, int n){
  for(int i = 0; i < n; i++){
    printf("%s/%s/%i/%i\n", banda[i].nome, banda[i].tipo, banda[i].num_int, banda[i].pos_rank);
  }
  return 0;
}

int procuraRank(Banda *banda, int n){
  int procura;
  printf("Qual posição do ranking deseja pesquisar:\n");
  scanf("%i", &procura);
  for(int i = 0; i < n; i++){
    if(banda[i].pos_rank == procura){
      printf("%s/%s/%i/%i\n", banda[i].nome, banda[i].tipo, banda[i].num_int, banda[i].pos_rank);
    }
  }
  return 0;
}

int main(){
  Banda banda[5];

  //chama a função de preencher o vetor
  preenchVet(banda, 5);

  //chama a função para exibir
  exibeVet(banda, 5);

  //chama a função de procurar no ranking
  procuraRank(banda, 5);

  return 0;
}
