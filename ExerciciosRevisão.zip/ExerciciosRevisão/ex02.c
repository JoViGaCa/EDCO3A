/**
* @file ex02.c
* @author João Carvalho
* @date 18 06 2021
* @brief Resoluçao do exercicio 1 da lista diagnóstica EDCO63A
Enunciado:  Fa¸ca um programa que receba do usu´ario um arquivo texto. Crie outro arquivo
texto de sa´ıda contendo o texto do arquivo de entrada original, por´em substituindo todas as vogais pelo
caractere ‘*’. Al´em disso, mostre na tela quantas linhas esse arquivo possui. Dentro do programa fa¸ca
o controle de erros, isto ´e, insira comandos que mostre se os arquivos foram abertos com sucesso, e caso
contr´ario, imprima uma mensagem de erro encerrando o programa
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  //variavel para saber quantas linhas
  int linhas = 1;

  //receber o nome do arquilo pelo usuário
  char nome[16];
  printf("Por favor digite o nome do arquivo:\n");
  fgets(nome,16,stdin);
  nome[strcspn(nome,"\n")] ='\0';
  setbuf(stdin,NULL);

  //abre o arquivo, retorna mensagem de erro caso não dê
  FILE *arq = fopen(nome,"r");
  if(!arq){
    printf("Erro ao abrir arquivo.\n");
    exit(1);
  }

  // cria um segundo arquivo
  FILE *arq2 = fopen("Novo_Arquivo.txt","w");
  if(!arq2){
    printf("Erro ao criar ou abrir o novo arquivo.\n");
    exit(1);
  }

  //variavel para analizar texto
  char c;
  //estrutura de repetição para analizar cada caractere do arquivo
  while((c = fgetc(arq)) != EOF){
    //verifica se é vogal
    if(c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'){
      c = '*';
    }
    if (c == '\n'){ // verifica se é quebra de linhas
      linhas++;
    }
    fputc(c,arq2);
  }

  //exibe quantidades de linhas
  printf("O arquivo tem %i linhas.\n", linhas);

  fclose(arq);
  fclose(arq2);
  return 0;
}
