/**
* @file ex04.c
* @author João Carvalho
* @date 18 06 2021
* @brief Fa¸ca um programa que leia um valor N e crie dinamicamente um
vetor com essa quantidade de elementos. Em seguida, passe esse vetor para uma fun¸c˜ao que vai ler os
elementos desse vetor. Depois, no programa principal, imprima os valores do vetor preenchido. Al´em disso,
antes de finalizar o programa, lembre-se de liberar a ´area de mem´oria alocada para armazenar os valores do
vetor.
*/

#include <stdio.h>
#include <stdlib.h>

int leVet(int* vetor, int n){
  //repetição controlada para ler
  for(int i = 0; i < n; i++){
    printf("Por favor digite o valor do elemento %i do vetor:\n", i+1);
    scanf("%i", &vetor[i]);
  }
  return 0;
}

int main(){
  //variavel do tamanho do vetor
  int n;

  //recebe o vetor
  printf("Por favor digite o tamanho do vetor:\n");
  scanf("%d", &n);

  //cria o vetor alocado dinamicamente
  int *vetor = (int *) malloc(n*sizeof(int));

  //chama a função para ler o vetor
  leVet(vetor, n);

  //exibe o valor do vetor
  for(int i = 0; i < n; i++){
    printf("%i ", vetor[i]);
  }

  free(vetor);
  return 0;
}
