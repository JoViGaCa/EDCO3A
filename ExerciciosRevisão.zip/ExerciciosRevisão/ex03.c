/**
* @file ex03.c
* @author João Carvalho
* @date 18 06 2021
* @brief Resoluçao do exercicio 1 da lista diagnóstica EDCO63A
Enunciado:  Escreva uma fun¸c˜ao recursiva para calcular o valor de um n´umero inteiro de base
x elevada a um expoente inteiro y.
*/

#include <stdio.h>
#include <stdlib.h>

int calcPot(int x, int y){
  //caso base, expoente igual a zero
  //coutros casos retorna ele vezes a potencia de 1 a menos
  if(y == 0){
    return 1;
  } else{
    return x * calcPot(x, y-1);
  }
}

int main(){
  int x, y;
  int resultado;

  //recebe o npumero e o expoente
  printf("Por favor digite o número e seu expoente:\n");
  scanf("%d %d", &x, &y);

  //resultado recebe o valor da função
  resultado = calcPot(x, y);

  //exibe resultado
  printf("O resultado é: %i\n", resultado);

  return 0;
}
