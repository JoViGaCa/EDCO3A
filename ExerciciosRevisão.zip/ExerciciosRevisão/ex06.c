/**
* @file ex06.c
* @author João Carvalho
* @date 18 06 2021
* @brief Como vimos na aula passada, um baralho normal frequentemente
usado em v´arios jogos para entretenimento pode ser codificado definindo dois tipos abstrato de dados:
• Carta: que representa uma carta f´ısica do baralho. Possui trˆes atributos: s´ımbolo/valor, o naipe, e
uma vari´avel booleana indicando se a carta j´a foi jogada ou n˜ao;
• Baralho: uma estrutura que representa um conjunto de Cartas.
****** O resto está no pdf, não foi colocado por conta do grande tamanho******
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

//Lista as Caracteristicas das cartas
char naipes[4] = {'O', 'E', 'C', 'P'};
char valor[13] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'D', 'J', 'Q', 'K'};

typedef struct {
  char valor;
  char naipe;
  bool foiJogada;
} Carta;

typedef struct {
  Carta carta[52];
} Baralho;

void criaBaralho(Baralho *baralho){
  // preenche o baralho de acordo com a enum
  for(int i = 0; i < 13; i++){
    for(int j = 0; j < 4; j++){
      baralho->carta[i*4 + j].valor = valor[i];
      baralho->carta[i*4 + j].naipe = naipes[j];
      baralho->carta[i*4 + j].foiJogada = 0;
    }
  }
}

int cartasNaoJogadas(Baralho *baralho){
  //variavel que mostra quantas cartas não foram jogadas
  int resultado = 0;
  //repetição para ver quais cartas foram jogadas
  for(int i = 0; i < 13; i++){
    for(int j = 0; j < 4; j++){
      if(baralho->carta[i*4 + j].foiJogada == 1){
        resultado++;
      }
    }
  }
  return resultado;
}

Carta veTopo(Baralho *baralho){
  //armazenar a carta no topo
  Carta top;
  //ver qual a carta do topo, indo do final do baralho até o começo
  for(int i = 12; i >= 0; i--){
    for(int j = 3; j >= 0; j--){
      if(baralho->carta[i*4 + j].foiJogada != 1){
        top = baralho->carta[i*4 + j];
        return top;
      }
    }
  }
}

Carta veFundo(Baralho *baralho){
  //armazenar a carta do fundo
  Carta fund;
  //ver qual a carta do fundo, indo do começo até o finaç
  for(int i = 0; i < 13; i++){
    for(int j = 0; j < 4; j++){
      if(baralho->carta[i*4 + j].foiJogada != 1){
        fund = baralho->carta[i*4 + j];
        return fund;
      }
    }
  }
}

int daCarta(Baralho* baralho, Carta* jogador, int n){
  srand(time(NULL));
  int igual = 0;
  //estrutura de repetição para ver qual carta do jogador será dada
  for(int i = 0; i < n; i++){
    do{
      igual = 0;
      //gera valores aleatórios para as cartas
      int j = rand() % 13;
      int k = rand() % 4;
      //atribui esses valores ao jogador
      jogador[i].valor = valor[j];
      jogador[i].naipe = naipes[k];
      //verifica se essas cartas são repitidas
      for(int l = 0; l < i; l++){
        if(jogador[l].valor == jogador[i].valor && jogador[l].naipe == jogador[i].naipe){
          igual = 1;
        }
      }
    } while (igual != 0);
    baralho->carta[i].foiJogada = 1;
  }


  return 0;
}

int main(){
  Baralho baralho;
  Carta topo;
  Carta fundo;
  Carta jogador[3];

  //variavel que mostra quantas cartas não foram jogadas
  int cartas_n_jog;

  //chama a função de criar o baralho
  criaBaralho(&baralho);

  //chama a função de consultar as cartas
  cartas_n_jog = cartasNaoJogadas(&baralho);
  printf("Cartas não jogadas: %i\n", cartas_n_jog);

  //chama a função para ver qual carta esta no topo
  topo = veTopo(&baralho);
  printf("Carta topo = %c %c\n", topo.valor, topo.naipe);

  //chama a função que vê qual carta esta no fundo
  fundo = veFundo(&baralho);
  printf("Carta fundo = %c %c\n", fundo.valor, fundo.naipe);

  //chama a função para dar as cartas ao jogador
  daCarta(&baralho, jogador, 3);
  for(int i = 0; i < 3; i++){
    printf("Carta %i do jogador: %c %c\n", i+1, jogador[i].valor, jogador[i].naipe);
  }

  return 0;
}
